package harish.test.com;

public class TempConve {
	
	public static double convertTemp(double  celsius){
		return (9.0 / 5) * celsius + 32;  
	}


}
