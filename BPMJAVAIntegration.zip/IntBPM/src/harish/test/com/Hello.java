package harish.test.com;
import java.util.UUID;

import teamworks.TWObject;
import teamworks.TWObjectFactory;


//Consume primitive type object in java and send primitiive type to BPM
public class Hello {
	
	public static String returnUniqueID(String name){
		
		UUID uniqueKey = UUID.randomUUID();
		
		System.out.print(uniqueKey+name);
		
		return uniqueKey+name;
	}
	
	//Consume TW Object in Java
	
public static void takeObject(Object obj){
		
		System.out.print("the input object is of type"+ obj.getClass().toString());
		
		if(obj instanceof TWObject){
			
			TWObject obj1 = (TWObject)obj;
			
			System.out.print("The property names are" + obj1.getPropertyNames());
			
			System.out.print("The property values are" + obj1.getPropertyValue("firstName"));
		}
	}

//Crate Java Object and Send to BPM
public static CarObject returnCarObj(){
	
	CarObject myCar = new CarObject();
	
	myCar.setMake("Honda");
	myCar.setModel("Accord");
	myCar.setYear(2000);
	
	return myCar;
	
}

//Create TW Object and send to BPM

public static TWObject createBPMObj(){
	try{
		TWObject person=TWObjectFactory.createObject();
		person.setPropertyValue("firstName","James");
		return person;
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return null;
}

									


}
